﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using ShopDataAccess;

namespace ShopBridge.Controllers
{
    public class ShopController : ApiController
    {
        [HttpGet]
        public async Task<HttpResponseMessage> GetItems(int page = 0, int limit = 1000, string availability = "All")
        {
            HttpResponseMessage returnMessage = new HttpResponseMessage();
            try
            {
                if (page >= 0 && limit > 0)
                {
                    using (EcommerceEntities entities = new EcommerceEntities())
                    {

                        if (availability.ToLower() == "all")
                            returnMessage = Request.CreateResponse(HttpStatusCode.OK, entities.ShopItems.OrderBy(i => i.ItemId).Skip(page * limit).Take(limit).ToList());
                        else if (availability.ToLower() == "instock")
                            returnMessage = Request.CreateResponse(HttpStatusCode.OK, entities.ShopItems.Where(s => s.IsAvailable).OrderBy(i => i.ItemId).Skip(page * limit).Take(limit).ToList());
                        else if (availability.ToLower() == "outofstock")
                            returnMessage = Request.CreateResponse(HttpStatusCode.OK, entities.ShopItems.Where(s => !s.IsAvailable).OrderBy(i => i.ItemId).Skip(page * limit).Take(limit).ToList());
                        else
                            returnMessage = Request.CreateResponse(HttpStatusCode.BadRequest, "Please select proper filter");
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            return await Task.FromResult(returnMessage);
        }

        [HttpGet]
        public HttpResponseMessage GetItem(int id)
        {
            using (EcommerceEntities entities = new EcommerceEntities())
            {
                var itemInfo = entities.ShopItems.Where(s => s.ItemId == id).FirstOrDefault();
                if (itemInfo != null)
                    return Request.CreateResponse(HttpStatusCode.OK, itemInfo);
                else
                    return Request.CreateResponse(HttpStatusCode.NotFound, "Item not found");
            }
        }

        [HttpPost]
        public async Task<HttpResponseMessage> AddItem(ShopItem shopItem)
        {
            HttpResponseMessage returnMessage = new HttpResponseMessage();
            try
            {
                using (EcommerceEntities entities = new EcommerceEntities())
                {
                    if (shopItem != null)
                    {
                        entities.ShopItems.Add(shopItem);
                        entities.SaveChanges();

                        returnMessage = Request.CreateResponse(HttpStatusCode.Created, shopItem);
                    }
                    else
                        returnMessage = Request.CreateResponse(HttpStatusCode.BadRequest);
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
            return await Task.FromResult(returnMessage);
        }

        [HttpDelete]
        public async Task<HttpResponseMessage> DeleteItem(int id)
        {
            HttpResponseMessage returnMessage = new HttpResponseMessage();
            try
            {
                using (EcommerceEntities entities = new EcommerceEntities())
                {
                    var itemToDelete = entities.ShopItems.Where(i => i.ItemId == id).FirstOrDefault();
                    if (itemToDelete != null)
                    {
                        entities.ShopItems.Remove(itemToDelete);
                        entities.SaveChanges();
                        returnMessage = Request.CreateResponse(HttpStatusCode.OK);
                    }
                    else
                        returnMessage = Request.CreateResponse(HttpStatusCode.BadRequest, "Item not found");
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
            return await Task.FromResult(returnMessage);
        }


        [HttpPut]
        public async Task<HttpResponseMessage> UpdateItem(int id, ShopItem shopItem)
        {
            HttpResponseMessage returnMessage = new HttpResponseMessage();
            try
            {
                using (EcommerceEntities entities = new EcommerceEntities())
                {
                    var itemToUpdate = entities.ShopItems.Where(i => i.ItemId == id).FirstOrDefault();
                    if (itemToUpdate != null)
                    {
                        itemToUpdate.ItemName = shopItem.ItemName;
                        itemToUpdate.ItemDescription = shopItem.ItemDescription;
                        itemToUpdate.Price = shopItem.Price;
                        itemToUpdate.IsAvailable = shopItem.IsAvailable;
                        entities.SaveChanges();
                        returnMessage = Request.CreateResponse(HttpStatusCode.OK);
                    }
                    else
                        returnMessage = Request.CreateResponse(HttpStatusCode.BadRequest, "Item not found");
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
            return await Task.FromResult(returnMessage);
        }
    }
}
